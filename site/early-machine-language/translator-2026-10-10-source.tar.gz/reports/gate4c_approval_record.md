# Gate 4C Approval Record

Status: **APPROVED — CANONICAL CORE RELEASE**  
Version: **1.0.0**

This approval covers 436 English sense records across 419 normalized lemmas. It preserves all 324 atomic meanings and all 28 approved compound graphs unchanged. Exact canonical labels are deterministic controlled inputs; polysemous and unsupported everyday readings require disambiguation, grammar, semantic IR, or a gap result.

Next authorized gate: **Gate 4D — coverage and ambiguity report**. General-English translation remains unauthorized.
