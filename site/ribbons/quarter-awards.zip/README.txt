Ten original awards, sixteen separate components, revised Galaxy Gala and its first version. All are unassigned design proposals. The front center ribbon on the revised Gala is the longest tail.
