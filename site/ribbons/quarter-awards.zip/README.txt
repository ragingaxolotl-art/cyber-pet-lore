The former Galaxy Gala is now the Divine Code Ribbon. An end-of-quarter honour recognizing effort. The teacher chooses recipients based on the effort they have shown. One to four clasp bars sit on the long center ribbon for a quarter; more clasps acknowledge greater effort. The four-clasp limit is per quarter.

Fictional lore — The Divine Code: In the tradition of this ribbon, the Divine Code is a luminous pattern revealed through patient work. It becomes clearer whenever someone practices, revises, asks for help, or returns to a difficult task. Its galaxy-colored folds hold many small points of light, each recalling an attempt that mattered. The long center ribbon carries up to four clasps: visible marks of effort that has been seen and valued. The blue flower at its heart represents the understanding that grows from continuing to try.

Other designs remain unassigned. Artwork filenames preserve their original design names.
